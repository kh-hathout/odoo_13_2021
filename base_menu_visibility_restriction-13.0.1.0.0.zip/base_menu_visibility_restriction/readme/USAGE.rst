To use this module, you need to:

#. Activate the developer mode
#. Go to *Settings > Technical > User interface > Menu Items*.
#. Search for any menu and edit it.
#. Update "Excluded groups" with one group.
#. Login with a user of that group, and you won't see such menu.

You can try with demo data for the menu Apps > App Store and user demo.
