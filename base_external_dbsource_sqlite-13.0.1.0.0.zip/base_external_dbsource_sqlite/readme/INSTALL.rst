To install this module, you need to:

* Install ``sqlalchemy`` python library
