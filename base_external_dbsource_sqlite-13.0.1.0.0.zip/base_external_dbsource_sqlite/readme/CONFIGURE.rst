To configure this module, you need to:

#. Database sources can be configured in Settings > Configuration ->
   Data sources.
