* Add X.509 authentication
