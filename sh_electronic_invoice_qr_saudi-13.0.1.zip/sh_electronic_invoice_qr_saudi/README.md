About
============
This module allows you to print a Saudi electronic invoice with a QR code in the sale, purchase, invoice, credit note With Base64 TLV QR Code. You can display the data of VAT with tax details in the sale, purchase, invoice, credit note With Base64 TLV QR Code. You can print receipts in regional and global languages, such as Arabic and English As per Saudi Arabia Zakat's regulations to apply specific terms to the electronic invoice by 4th of Dec 2021.



Installation
============
1) Copy module files to addon folder.
2) Restart odoo service (sudo service odoo-server restart).
3) Go to your odoo instance and open apps (make sure to activate debug mode).
4) click on update app list.
5) search module name and hit install button.

Any Problem with module?
=====================================
Please create your ticket here https://softhealer.com/support

Softhealer Technologies Doubt/Inquiry/Sales/Customization Team
=====================================
Skype: live:softhealertechnologies
What's app: +917984575681
E-Mail: support@softhealer.com
Website: https://softhealer.com
