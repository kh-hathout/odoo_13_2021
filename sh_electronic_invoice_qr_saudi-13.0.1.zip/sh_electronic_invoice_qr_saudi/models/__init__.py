# -*- coding: utf-8 -*-
# Part of Softhealer Technologies.
from . import res_company
from . import res_partner
from . import account_move
from . import sale_order
from . import purchase_order
from . import inherit_product