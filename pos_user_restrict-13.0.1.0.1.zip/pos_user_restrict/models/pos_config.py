# -*- coding: utf-8 -*-

from odoo import models


class PosConfig(models.Model):
    _inherit = "pos.config"
