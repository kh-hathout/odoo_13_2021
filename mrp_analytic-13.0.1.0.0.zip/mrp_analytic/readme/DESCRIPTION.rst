This module links the manufacturing area with analytic management.

For now, it adds analytic account configuration for manufacturing orders,
and their corresponding shortcuts. Other modules can take advantage of
this link for other usages.
