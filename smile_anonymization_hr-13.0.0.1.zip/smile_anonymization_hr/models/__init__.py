# -*- coding: utf-8 -*-
# (C) 2019 Smile (<http://www.smile.fr>)
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import hr_department
from . import hr_employee
from . import resource_calendar_leaves
from . import resource_calendar
from . import resource_resource
