# -*- coding: utf-8 -*-
# (C) 2019 Smile (<http://www.smile.fr>)
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import ir_attachment
from . import ir_model_fields
from . import mail_mail
from . import mail_message
from . import res_partner_bank
from . import res_partner_title
from . import res_partner
from . import res_users
from . import mail_tracking_value
