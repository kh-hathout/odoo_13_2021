# -*- coding: utf-8 -*-
{
    'name': "Disable Database Manager",

    'summary': 'Disable Database Manager',
    
    'description' : """
        * Disable Database Manager
    """,

    "author": "Openinside",
    "license": "OPL-1",
    'website': "https://www.open-inside.com",
    "price" : 0,
    "currency": 'EUR',
    'category': 'Extra Tools',
    'version': '13.0.1.1.0',

    # any module necessary for this one to work correctly
    'depends': ['web'],

    # always loaded
    'data': [
        
        
    ],    
    'odoo-apps' : True 
}