# ©  2015-2021 Deltatech
# See README.rst file on addons root folder for license details
{
    "name": "Deltatech Generic Partner Restriction",
    "summary": " Generic Partner restriction",
    "version": "13.0.2.0.0",
    "author": "Terrabit, cojocariudaniel1",
    "license": "LGPL-3",
    "website": "https://www.terrabit.ro",
    "category": "",
    "depends": ["account", "deltatech_partner_generic"],
    "data": ["views/account_view_jurnal.xml"],
    "images": [],
    "development_status": "Production/Stable",
    "maintainers": ["cojocariudaniel1"],
}
