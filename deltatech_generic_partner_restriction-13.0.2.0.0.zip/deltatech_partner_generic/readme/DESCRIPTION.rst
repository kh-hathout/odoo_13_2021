Features:
 - definire partener generic
 - defining generic partner
