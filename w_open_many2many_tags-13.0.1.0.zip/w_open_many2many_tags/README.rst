Wedoo | Widget Open Many2many Tags
-----------------------------------
This widget works similar to many2many_tags, but with the
difference that clicking on an element opens the corresponding form.

Usage
======
    <field name="many2many_field" widget="open_many2many_tags" />

Credits
=======

**Contributors**

* Randy La Rosa Alvarez <rra@wedoo.tech> (Developer)
