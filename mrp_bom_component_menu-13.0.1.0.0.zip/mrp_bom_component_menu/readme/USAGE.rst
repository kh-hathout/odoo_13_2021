To use this module, you need to:

#. Go to menu *Manufacturing -> Master Data -> Bill of Material Components*.
