Adds a menu item *Bill of Material Components*.
