## Module <invoice_stock_move>

#### 11.11.2019
#### Version 13.0.1.0.0
#### ADD

Initial Commit

#### 17.01.2020
#### Version 13.0.1.1.1
#### FIX

Delivery and Receipts Bug fixed.

#### 30.01.2020
#### Version 13.0.1.1.2
#### FIX

Bug fixed.

#### 20.02.2020
#### Version 13.0.1.2.3
#### FIX

Invoice Post Bug fixed.
