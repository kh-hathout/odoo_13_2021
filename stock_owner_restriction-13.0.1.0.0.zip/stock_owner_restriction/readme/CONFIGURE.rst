To configure this module, you need to:

#. Make sure you have selected the consignment option on inventory settings.
#. Go to *Inventory > Configuration > Operation types*.
#. Select one operation type or create one and set owner_restriction field to desired value.
