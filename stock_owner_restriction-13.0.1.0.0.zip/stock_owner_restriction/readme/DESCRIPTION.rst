This module extends the functionality of stock module to allow to restrict
product quantities (quants) for stock operations like as reserve quantities or
product quantity available info.
