To use this module, you need to:

#. Go to *Sales -> Orders -> Quotations* and create a new quotation.
#. Add some storable products and confirm the quotation.
#. Go to the related pickings and confirm them.
#. Go back to the quotation, try to cancel it and you will get a validation
   message that will not let you cancel the order.
