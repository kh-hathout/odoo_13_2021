This module extends the functionality of Sales to avoid canceling sales orders
with 'Done' pickings.

Derived from:
https://github.com/odoo/odoo/commit/abc9ee8e3b33079ddedcaed39fea9116fb0aebff
