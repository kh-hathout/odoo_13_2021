# Part of AktivSoftware See LICENSE file for full
# copyright and licensing details.

from . import sale_order_line
