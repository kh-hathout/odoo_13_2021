Open ERP System :- Odoo 13 Version 

Installation 
============
Install the Application => Apps -> Sale Price Change Restriction (Technical Name: restrict_saleprice_change)

Version
========
	Odoo 13 version

Module Configuration Guideline
=============================

	User can be given rights to change the Unit Price of product on sale order
	Just check 'Manage Sales Price Change' inside Users ---> Other Extra Rights settings 
	(Odoo developer mode is required)


