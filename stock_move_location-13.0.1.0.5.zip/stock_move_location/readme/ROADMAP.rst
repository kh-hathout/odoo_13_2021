Change the current implementation (suggested by Denis Roussel from ACSONE):

* A new parameter on stock picking types : 'Product Change Location' (with a little help).
* With this, go to the dashboard, create a picking with that type.
* Add a button on the picking form which is visible with that type that fill in the picking as now
* Nice to have: add a magic button on locations that with context creates a new picking of that type with the origin location already filled in.
