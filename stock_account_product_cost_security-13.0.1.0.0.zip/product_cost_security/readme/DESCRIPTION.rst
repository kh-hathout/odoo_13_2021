Adds a security group for product cost price field.
Only users with this group can view this field.
