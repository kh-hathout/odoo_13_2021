This module depends on product_cost_security and stock_account modules to
help their to hide some elements for product cost security group.

This module is self-installable.
