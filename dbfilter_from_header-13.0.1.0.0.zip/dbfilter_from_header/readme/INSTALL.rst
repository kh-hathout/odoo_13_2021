To install this module, you only need to add it to your addons, and load it as
a server-wide module.

This can be done with the ``server_wide_modules`` parameter in ``/etc/odoo.conf``
or with the ``--load`` command-line parameter

``server_wide_modules = "web, dbfilter_from_header"``
